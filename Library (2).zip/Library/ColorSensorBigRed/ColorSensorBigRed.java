/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot;

import edu.wpi.first.wpilibj.util.Color;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.I2C;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SpeedControllerGroup;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.DoubleSolenoid.Value;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.I2C.Port;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.DriverStation;


//color sensor
import com.revrobotics.ColorSensorV3;
import com.revrobotics.ColorMatchResult;
import com.revrobotics.ColorMatch;

//talon srx motor controller
import com.ctre.phoenix.motorcontrol.*;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonFX;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;


/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the TimedRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the build.gradle file in the
 * project.
 */
public class Robot extends TimedRobot {

    // Declaring moters & Arcade drive
    VictorSP right1 = new VictorSP(2);
    VictorSP right2 = new VictorSP(3);
    VictorSP left1 = new VictorSP(1);
    VictorSP left2 = new VictorSP(0);

    SpeedControllerGroup left = new SpeedControllerGroup(left1, left2);
    SpeedControllerGroup right = new SpeedControllerGroup(right1, right2);

    DifferentialDrive driveBase = new DifferentialDrive(right,left);
    

    // Declaring Joystick & XBox Controler.
    Joystick jStick = new Joystick(0);
    Joystick xBox = new Joystick(1);

    // Declaring the Compresser and DoubleSolenoid.
    Compressor copmres = new Compressor();
    DoubleSolenoid sLift = new DoubleSolenoid(1,6);
    DoubleSolenoid iLift = new DoubleSolenoid(2,5);
    DoubleSolenoid trigger = new DoubleSolenoid(0,7);
    DoubleSolenoid lockPin = new DoubleSolenoid(4,3);

    // Declaring non-drive moters 
    VictorSP intake = new VictorSP(8);
    VictorSP shoot1 = new VictorSP(5);
    VictorSP shoot2 = new VictorSP(6);
    Talon climb = new Talon(9);

    // Declaring talon srx stuff
    WPI_TalonSRX spinner = new WPI_TalonSRX(1);

  
    // Declaring limit switches
    DigitalInput topLimit = new DigitalInput(1);
    DigitalInput bottomLimit = new DigitalInput(2);


    //Declaring color sensor
    I2C.Port cPort = I2C.Port.kOnboard;
    ColorSensorV3 cSensor = new ColorSensorV3(cPort);
    char colorString;



    private final Color kBlueTarget = ColorMatch.makeColor(0.143, 0.427, 0.429);
    private final Color kGreenTarget = ColorMatch.makeColor(0.15, 0.6, 0.240);
    private final Color kRedTarget = ColorMatch.makeColor(0.49, 0.37, 0.13);
    private final Color kYellowTarget = ColorMatch.makeColor(0.31, 0.57, 0.12);

    //updates all information
    //motors
    double s1Speed = 0;
    double s2Speed = 0;
    double liftSpeed = 0;
    double intakeSpeed = 0;

   //solenoids
     Value intakeValue =                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                Value.kOff;
     Value shootLiftValue = Value.kOff;
     Value lockValue = Value.kOff;
     Value triggerValue = Value.kOff;

     private final ColorMatch m_colorMatcher = new ColorMatch();


     String gameData;

     int colorChanges = 0;
     char lastColor = 'Z';







  /**
   * This function is run when the robot is first started up and should be
   * used for any initialization code.
   */
  @Override
  public void robotInit() {
    driveBase.setSafetyEnabled(false);

    
    m_colorMatcher.addColorMatch(kBlueTarget);
    m_colorMatcher.addColorMatch(kGreenTarget);
    m_colorMatcher.addColorMatch(kRedTarget);
    m_colorMatcher.addColorMatch(kYellowTarget); 



  }

  /**
   * This function is called every robot packet, no matter the mode. Use
   * this for items like diagnostics that you want ran during disabled,
   * autonomous, teleoperated and test.
   *
   * <p>This runs after the mode specific periodic functions, but before
   * LiveWindow and SmartDashboard integrated updating.
   */
  @Override
  public void robotPeriodic() {

    Color detectedColor = cSensor.getColor();
    ColorMatchResult match = m_colorMatcher.matchClosestColor(detectedColor);

    if (match.color == kBlueTarget) {
      colorString = 'B';
    } else if (match.color == kRedTarget) {
      colorString = 'R';
    } else if (match.color == kGreenTarget) {
      colorString = 'G';
    } else if (match.color == kYellowTarget) {
      colorString = 'Y';
    } else {
      colorString = 'U';
    }

    SmartDashboard.putNumber("Red", detectedColor.red);
    SmartDashboard.putNumber("Green", detectedColor.green);
    SmartDashboard.putNumber("Blue", detectedColor.blue);
    SmartDashboard.putNumber("Confidence", match.confidence);

    String test = colorString + " ";
    SmartDashboard.putString("Color", test);

  }

  /**
   * This autonomous (along with the chooser code above) shows how to select
   * between different autonomous modes using the dashboard. The sendable
   * chooser code works with the Java SmartDashboard. If you prefer the
   * LabVIEW Dashboard, remove all of the chooser code and uncomment the
   * getString line to get the auto name from the text box below the Gyro
   *
   * <p>You can add additional auto modes by adding additional comparisons to
   * the switch structure below with additional strings. If using the
   * SendableChooser make sure to add them to the chooser code above as well.
   */
  @Override
  public void autonomousInit() {


  }

  /**
   * This function is called periodically during autonomous.
   */
  @Override
  public void autonomousPeriodic() {

    
  }

  public int colorChange(char oldColor, char newColor){
    
      if(oldColor == newColor){
        return 0;
      }else{
        return 1;
      }

  }

//runs once at the beggingn of teleop
  @Override
  public void teleopInit() {
    // TODO Auto-generated method stub
    super.teleopInit();
     colorChanges = -1;
     lastColor = 'Z';

  }


  /**
   * This function is called periodically during operator control.
   */
  @Override
  public void teleopPeriodic() {
    gameData = DriverStation.getInstance().getGameSpecificMessage();

    String[] colors = {"R","G","B","Y"};

    if(xBox.getRawButton(6)){ //right bumper
      colorChanges += colorChange(colorString, lastColor);

      if(colorChanges < 30){
        spinner.set(0.2);
      }else{
        spinner.set(0);
      }

      lastColor = colorString;

    }else{

    }
    SmartDashboard.putNumber("ColorChanges", colorChanges);

    //finds specific color
    if(gameData.length() > 0){
      //talon stuff
      if(xBox.getRawButton(3) && colorString != gameData.charAt(0)){
        spinner.set(0.2);
      }else{
        spinner.set(0);
      }
    }else{
      
    }

    //line below is all that is needed to make robot move
    driveBase.arcadeDrive(jStick.getY(), jStick.getZ(), true);


    //if b is pressed start intake process
    if(xBox.getRawButton(2)){

      intakeValue = Value.kReverse;

      intakeSpeed = 0.8;
      s1Speed = -0.75;
      s2Speed = -0.75;

    }else{ //if not pressed reset stuff
      intakeSpeed = 0;
      s1Speed = 0;
      s2Speed = 0;
    }

    //if joystick thumb button is pressed charge up shooter motors
    if(jStick.getRawButton(2)){
      s1Speed = 1;
      s2Speed = 1;
    }

    //if joystick trigger is pressed shoot the ball!
    if(jStick.getRawButton(1)){
      triggerValue = Value.kReverse;
    }else{
      triggerValue = Value.kForward;
    }



    //if "A" is pressed toggle lock pin (for testing)
    //simple toggle switch using getRawButtonPressed();
    if(xBox.getRawButtonPressed(1)){
      if(lockPin.get() == Value.kForward){
        lockValue = Value.kReverse;
      }else{
        lockValue = Value.kForward;
      }
    }


    //if "Y" is pressed toggle intake lift
    if(xBox.getRawButtonPressed(4)){
      if(iLift.get() == Value.kForward){
        intakeValue = Value.kReverse;
      }else{
        intakeValue = Value.kForward;
      }
    }

    //if the slider is up raise the shooter
    if(jStick.getRawAxis(3) > 0){
      shootLiftValue = Value.kReverse; //pushes out and lays flat
    }else{
      shootLiftValue = Value.kForward; //pushes out and lays flat
    }

    //if right trigger is pressed pull lifter in and top limit isn't pressed
    //else if left trigger pressed let lifter out and bottom limit isn't pressed
    //else climber doesnt move
    //this is setup to kill motors to prevent overwinding
    if(xBox.getRawAxis(3) > 0.2 && topLimit.get()){
      liftSpeed = -(xBox.getRawAxis(3));
    }else if(xBox.getRawAxis(2) >0.2 && bottomLimit.get()){
      liftSpeed = xBox.getRawAxis(2);
      lockValue = Value.kReverse;
    }else{
      liftSpeed = 0;
    }
    
    //if top limit is pressed eject lock pin so it cant fall down
    if(!topLimit.get()){
      lockValue = Value.kForward;
    }


    //setting motor speeds
    shoot1.set(s1Speed);
    shoot2.set(s2Speed);
    intake.set(intakeSpeed);
    climb.set(liftSpeed);

    //setting pnuematics
    sLift.set(shootLiftValue);
    iLift.set(intakeValue);
    //lockpin trigger
    lockPin.set(lockValue);
    trigger.set(triggerValue);






  }


  /**
   * This function is called periodically during test mode.
   */
  @Override
  public void testPeriodic() {
  }
}
