/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot;

import com.ctre.phoenix.time.StopWatch;


import javax.naming.TimeLimitExceededException;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.StickyFaults;

import edu.wpi.cscore.CameraServerJNI;
import edu.wpi.first.cameraserver.CameraServer;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.GenericHID;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.SpeedControllerGroup;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.Victor;
import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonFX;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;
import edu.wpi.first.cameraserver.CameraServer;
import edu.wpi.first.networktables.NetworkTable;
import edu.wpi.first.networktables.NetworkTableEntry;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.cscore.UsbCamera;
import java.lang.Math;
/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the TimedRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the build.gradle file in the
 * project.
 */
public class Robot extends TimedRobot {
  //motors
  WPI_TalonFX rightLeaderFx = new WPI_TalonFX(2);
  WPI_TalonFX  leftLeaderFx = new WPI_TalonFX (3);
  WPI_TalonFX rightFollowerFx = new WPI_TalonFX(1);
  WPI_TalonFX leftFollowerFx = new WPI_TalonFX(0);

  //speed controllers
  SpeedControllerGroup right = new SpeedControllerGroup(rightLeaderFx, rightFollowerFx);
  SpeedControllerGroup left = new SpeedControllerGroup(leftLeaderFx, leftFollowerFx);

  //drive base
  DifferentialDrive driveBase = new DifferentialDrive(right,left);


  //joystick
  Joystick stick = new Joystick(3);
  XboxController Xbox = new XboxController(0);

  //hopper motors
  WPI_TalonSRX topHop = new WPI_TalonSRX(4);
  WPI_TalonSRX bottomHop = new WPI_TalonSRX(5);

  // intake
  VictorSP intake = new VictorSP(1);

  //shooters
  VictorSP shootertop = new VictorSP(3);
  VictorSP shooterbottom = new VictorSP(4);

  //climbers 
  VictorSP climber1 = new VictorSP(5);
  VictorSP climber2 = new VictorSP(6);

  //IR gate
  DigitalInput breakBeamReciever = new DigitalInput(8);

  //timer
   Timer time = new Timer();
   Timer time2 = new Timer();
   
  /**
   * This function is run when the robot is first started up and should be used
   * for any initialization code.
   */
  @Override
  public void robotInit() {

    CameraServer.getInstance().startAutomaticCapture();

  }

  /**
   * This function is called every robot packet, no matter the mode. Use this for
   * items like diagnostics that you want ran during disabled, autonomous,
   * teleoperated and test.
   *
   * <p>
   * This runs after the mode specific periodic functions, but before LiveWindow
   * and SmartDashboard integrated updating.
   */
  @Override
  public void robotPeriodic() {

    
    System.out.println(stick.getPOV());
    //System.out.println(breakBeamReciever.get());

  }

  /**
   * This autonomous (along with the chooser code above) shows how to select
   * between different autonomous modes using the dashboard. The sendable chooser
   * code works with the Java SmartDashboard. If you prefer the LabVIEW Dashboard,
   * remove all of the chooser code and uncomment the getString line to get the
   * auto name from the text box below the Gyro
   *
   * <p>
   * You can add additional auto modes by adding additional comparisons to the
   * switch structure below with additional strings. If using the SendableChooser
   * make sure to add them to the chooser code above as well.
   */
  @Override
  public void autonomousInit() {

    time.start();

  }

  /**
   * This function is called periodically during autonomous.
   */
  @Override
  public void autonomousPeriodic() {

    shootertop.set(-0.0);
    shooterbottom.set(-0);

   if(time.get() < 2){ 
    driveBase.arcadeDrive( 0.4, 0);


  }else if(time.get() < 4.5){

      driveBase.arcadeDrive(0, 0);
      topHop.set(ControlMode.PercentOutput, -.7);
      bottomHop.set(ControlMode.PercentOutput, .2);
      shootertop.set(-1);
      shooterbottom.set(-1);

  }else if(time.get() < 5 ){

      shootertop.set(-1);
      shooterbottom.set(-1);
      
   }else if(time.get() < 5.2){

      topHop.set(ControlMode.PercentOutput, -.7);
      bottomHop.set(ControlMode.PercentOutput, .2);
      shootertop.set(-1);
      shooterbottom.set(-1);


    }else if(time.get() < 6.5) {

      driveBase.arcadeDrive(0, 0);
      bottomHop.set(ControlMode.PercentOutput, 0);
      topHop.set(ControlMode.PercentOutput, 0);


    } 



  }

  /**
   * This function is called periodically during operator control.
   */
  @Override
  public void teleopPeriodic() {

    //drive
    driveBase.arcadeDrive(stick.getY(), stick.getZ(),true);

    //motors stay at zero unless re assigned
    topHop.set(ControlMode.PercentOutput, 0);
    bottomHop.set(ControlMode.PercentOutput, 0);
    intake.set(0);
    shooterbottom.set(0);
    shootertop.set(0);
    climber1.set(0);
    climber2.set(0);



     //if()

    //thumb button to intake
    if(stick.getRawButton(2)){ //intake
      intake.set(-.6);
    }

    //auto index, in hopper, if a ball is in way
    if(!breakBeamReciever.get()){
      topHop.set(ControlMode.PercentOutput, -.6);
      bottomHop.set(ControlMode.PercentOutput, .2);
     }

     //trigger makes shooter go vroom
    if(stick.getRawButton(1)){

      shootertop.set(-1); //vroom at fiddy percent
      shooterbottom.set(-1); //vroom fiddy percent

      if(stick.getRawButton(2)){ //if intake button pressed, also move hopper
        
        topHop.set(ControlMode.PercentOutput, -.7);
        bottomHop.set(ControlMode.PercentOutput, .2);

      }


    }
    //Intake Out
    if(stick.getRawButton(4)){
      intake.set(-1);
      topHop.set(ControlMode.PercentOutput, .7);
      bottomHop.set(ControlMode.PercentOutput, -.2);
    }
    //Belt Override
    if(stick.getRawButton(3)){
      topHop.set(ControlMode.PercentOutput, -.7);
      bottomHop.set(ControlMode.PercentOutput, .2);
    }

    //climber stuff
    if(stick.getPOV() == 0){ //reverse climber motors
      climber1.set(1);
      climber2.set(1);
    }else if(stick.getPOV() == 180){//forward
      climber1.set(-1);
      climber2.set(-1);
    }



  }






  /** 
   * This function is called periodically during test mode.
   */
  @Override
  public void teleopPeriodic() {
    m_robotDrive.arcadeDrive(-Xbox.getY(), Xbox.getX());

    final NetworkTable table = NetworkTableInstance.getDefault().getTable("limelight");
    final NetworkTableEntry tx = table.getEntry("tx");
    final NetworkTableEntry ty = table.getEntry("ty");
    final NetworkTableEntry ta = table.getEntry("ta");
    final NetworkTableEntry tv = table.getEntry("tv");

  
    //read values periodically
    final double x = tx.getDouble(0.0);
    final double y = ty.getDouble(0.0);
    final double area = ta.getDouble(0.0);
    
    //post to smart dashboard periodically
    SmartDashboard.putNumber("LimelightX", x);
    SmartDashboard.putNumber("LimelightY", y);
    SmartDashboard.putNumber("LimelightArea", area);

    double min = 0.45;
    double max = .9;
    double turnSpeed = 0;
    double ax = Math.abs(x);
    double fov = 60;
    double maxOffset = fov/2;
    double forward = 0;
    



    if(x < 0){
      turnSpeed = ax/maxOffset;
    }else{
      turnSpeed = x/maxOffset;
    }




    if(x > 1){

      SmartDashboard.putString("LimelightTolerance","too big");

    if(turnSpeed < min){
      turnSpeed = min;
    }else if (turnSpeed > max){
      turnSpeed = max;
    }else{
      
    }

  }else if(x < -1){

    SmartDashboard.putString("LimelightTolerance","too small");

    //TODO below logic isn't working correctly

    if(turnSpeed < min){  //if turnspeed is greater than -.45, turnspeed = -.45
      turnSpeed = -min;
    }else if (turnSpeed > max){   //if turnspeed is less than -.9, turnspeed = -.9
      turnSpeed = -max;
    }else{
       turnSpeed = -turnSpeed;    //if X is less than -1, turn speed equals -turnspeed. if x is less than -1, robot turns left.
    }
        // turnSpeed = -0.5;

  }else{

    SmartDashboard.putString("LimelightTolerance","just right");

    turnSpeed = 0;

  } 

  SmartDashboard.putNumber("Turn Speed", x);
  if(Xbox.getRawButton(4)){
    m_robotDrive.arcadeDrive( 0, turnSpeed);
  }





  if (area < 9){
    forward = 0.5;   
  }else if (area > 9){
    forward = -0;
  }
  if(Xbox.getRawButton(3)){
    m_robotDrive.arcadeDrive( forward,0 );
  }
}






  
  /**
   * This function is called periodically during test mode.
   */
  @Override
  public void testPeriodic() {

    final NetworkTable table = NetworkTableInstance.getDefault().getTable("limelight");
    final NetworkTableEntry tx = table.getEntry("tx");
    final NetworkTableEntry ty = table.getEntry("ty");
    final NetworkTableEntry ta = table.getEntry("ta");
    
    //read values periodically
    final double x = tx.getDouble(0.0);
    final double y = ty.getDouble(0.0);
    final double area = ta.getDouble(0.0);
    
    //post to smart dashboard periodically
    SmartDashboard.putNumber("LimelightX", x);
    SmartDashboard.putNumber("LimelightY", y);
    SmartDashboard.putNumber("LimelightArea", area);

  }
}
}
