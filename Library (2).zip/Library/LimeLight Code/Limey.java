/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot;

import java.lang.Math.*;
import edu.wpi.first.wpilibj.Spark;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.DoubleSolenoid.Value;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
//import sun.management.jmxremote.ConnectorBootstrap.DefaultValues;
import edu.wpi.first.cameraserver.CameraServer;
import edu.wpi.first.networktables.NetworkTable;
import edu.wpi.first.networktables.NetworkTableEntry;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.cscore.UsbCamera;
import java.lang.Math;


/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the TimedRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends TimedRobot {
  private final DifferentialDrive m_robotDrive
      = new DifferentialDrive(new Spark(1), new Spark(0));
  private final XboxController Xbox = new XboxController(0);
  private final Timer m_timer = new Timer();
  //Compressor compressor = new Compressor();
  //DoubleSolenoid Solenoid = new DoubleSolenoid(0,7);
  UsbCamera camera2;
  NetworkTableEntry cameraSelection;



  

  /**
   * This function is run when the robot is first started up and should be
   * used for any initialization code.
   */
  @Override
  public void robotInit(){
    camera2 = CameraServer.getInstance().startAutomaticCapture();
    cameraSelection = NetworkTableInstance.getDefault().getTable("").getEntry("CameraSelection");
  }

  /**
   * This function is run once each time the robot enters autonomous mode.
   */
  @Override
  public void autonomousInit() {
    m_timer.reset();
    m_timer.start();
  }

  /**
   * This function is called periodically during autonomous.
   */
  @Override
  public void autonomousPeriodic() {
    // Drive for 2 seconds
   
     







   }
    
     
  
  
  

     
  

  /**
   * This function is called once each time the robot enters teleoperated mode.
   */
  @Override
  public void teleopInit() {
    
  }

  /**
   * This function is called periodically during teleoperated mode.
   */
  @Override
  public void teleopPeriodic() {
    m_robotDrive.arcadeDrive(-Xbox.getY(), Xbox.getX());

    final NetworkTable table = NetworkTableInstance.getDefault().getTable("limelight");
    final NetworkTableEntry tx = table.getEntry("tx");
    final NetworkTableEntry ty = table.getEntry("ty");
    final NetworkTableEntry ta = table.getEntry("ta");
    final NetworkTableEntry tv = table.getEntry("tv");

  
    //read values periodically
    final double x = tx.getDouble(0.0);
    final double y = ty.getDouble(0.0);
    final double area = ta.getDouble(0.0);
    
    //post to smart dashboard periodically
    SmartDashboard.putNumber("LimelightX", x);
    SmartDashboard.putNumber("LimelightY", y);
    SmartDashboard.putNumber("LimelightArea", area);

    double min = 0.45;
    double max = .9;
    double turnSpeed = 0;
    double ax = Math.abs(x);
    double fov = 60;
    double maxOffset = fov/2;
    double forward = 0;
    



    if(x < 0){
      turnSpeed = ax/maxOffset;
    }else{
      turnSpeed = x/maxOffset;
    }




    if(x > 1){

      SmartDashboard.putString("LimelightTolerance","too big");

    if(turnSpeed < min){
      turnSpeed = min;
    }else if (turnSpeed > max){
      turnSpeed = max;
    }else{
      
    }

  }else if(x < -1){

    SmartDashboard.putString("LimelightTolerance","too small");

    //TODO below logic isn't working correctly

    if(turnSpeed < min){  //if turnspeed is greater than -.45, turnspeed = -.45
      turnSpeed = -min;
    }else if (turnSpeed > max){   //if turnspeed is less than -.9, turnspeed = -.9
      turnSpeed = -max;
    }else{
       turnSpeed = -turnSpeed;    //if X is less than -1, turn speed equals -turnspeed. if x is less than -1, robot turns left.
    }
        // turnSpeed = -0.5;

  }else{

    SmartDashboard.putString("LimelightTolerance","just right");

    turnSpeed = 0;

  } 

  SmartDashboard.putNumber("Turn Speed", x);
  if(Xbox.getRawButton(4)){
    m_robotDrive.arcadeDrive( 0, turnSpeed);
  }





  if (area < 9){
    forward = 0.5;   
  }else if (area > 9){
    forward = -0;
  }
  if(Xbox.getRawButton(3)){
    m_robotDrive.arcadeDrive( forward,0 );
  }
}






  
  /**
   * This function is called periodically during test mode.
   */
  @Override
  public void testPeriodic() {

    final NetworkTable table = NetworkTableInstance.getDefault().getTable("limelight");
    final NetworkTableEntry tx = table.getEntry("tx");
    final NetworkTableEntry ty = table.getEntry("ty");
    final NetworkTableEntry ta = table.getEntry("ta");
    
    //read values periodically
    final double x = tx.getDouble(0.0);
    final double y = ty.getDouble(0.0);
    final double area = ta.getDouble(0.0);
    
    //post to smart dashboard periodically
    SmartDashboard.putNumber("LimelightX", x);
    SmartDashboard.putNumber("LimelightY", y);
    SmartDashboard.putNumber("LimelightArea", area);

  }
}
