/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot;

import com.ctre.phoenix.motorcontrol.can.WPI_TalonFX;
import com.ctre.phoenix.motorcontrol.can.TalonSRX;
import com.ctre.phoenix.time.StopWatch;

import java.util.Timer;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.StickyFaults;

import edu.wpi.cscore.CameraServerJNI;
import edu.wpi.first.cameraserver.CameraServer;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.GenericHID;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.SpeedControllerGroup;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.Victor;
import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the TimedRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the build.gradle file in the
 * project.
 */
public class Robot extends TimedRobot {
  //motors
  WPI_TalonFX rightLeaderFx = new WPI_TalonFX(2);
  WPI_TalonFX  leftLeaderFx = new WPI_TalonFX (3);
  WPI_TalonFX rightFollowerFx = new WPI_TalonFX(1);
  WPI_TalonFX leftFollowerFx = new WPI_TalonFX(0);

  //speed controllers
  SpeedControllerGroup right = new SpeedControllerGroup(rightLeaderFx, rightFollowerFx);
  SpeedControllerGroup left = new SpeedControllerGroup(leftLeaderFx, leftFollowerFx);

  //drive base
  DifferentialDrive driveBase = new DifferentialDrive(right,left);


  //joystick
  Joystick stick = new Joystick(0);

  //hopper motors
  TalonSRX topHop = new TalonSRX(4);
  TalonSRX bottomHop = new TalonSRX(5);

  // intake
  VictorSP intake = new VictorSP(1);

  //shooters
  VictorSP shootertop = new VictorSP(3);
  VictorSP shooterbottom = new VictorSP(4);

  //climbers
  VictorSP climber1 = new VictorSP(5);
  VictorSP climber2 = new VictorSP(6);

  //IR gate
  DigitalInput breakBeamReciever = new DigitalInput(8);


  /**
   * This function is run when the robot is first started up and should be used
   * for any initialization code.
   */
  @Override
  public void robotInit() {

    CameraServer.getInstance().startAutomaticCapture();

  }

  /**
   * This function is called every robot packet, no matter the mode. Use this for
   * items like diagnostics that you want ran during disabled, autonomous,
   * teleoperated and test.
   *
   * <p>
   * This runs after the mode specific periodic functions, but before LiveWindow
   * and SmartDashboard integrated updating.
   */
  @Override
  public void robotPeriodic() {


    System.out.println(stick.getPOV());
    //System.out.println(breakBeamReciever.get());

  }

  /**
   * This autonomous (along with the chooser code above) shows how to select
   * between different autonomous modes using the dashboard. The sendable chooser
   * code works with the Java SmartDashboard. If you prefer the LabVIEW Dashboard,
   * remove all of the chooser code and uncomment the getString line to get the
   * auto name from the text box below the Gyro
   *
   * <p>
   * You can add additional auto modes by adding additional comparisons to the
   * switch structure below with additional strings. If using the SendableChooser
   * make sure to add them to the chooser code above as well.
   */
  @Override
  public void autonomousInit() {

  }

  /**
   * This function is called periodically during autonomous.
   */
  @Override
  public void autonomousPeriodic() {

  }

  /**
   * This function is called periodically during operator control.
   */
  @Override
  public void teleopPeriodic() {

    //drive
    driveBase.arcadeDrive(stick.getY(), 0.7 * stick.getZ(),true);

    //motors stay at zero unless re assigned
    topHop.set(ControlMode.PercentOutput, 0);
    bottomHop.set(ControlMode.PercentOutput, 0);
    intake.set(0);
    shooterbottom.set(0);
    shootertop.set(0);
    climber1.set(0);
    climber2.set(0);


    //thumb button to intake
    if(stick.getRawButton(2)){ //intake
      intake.set(-.6);
    }

    //auto index, in hopper, if a ball is in way
    if(!breakBeamReciever.get()){
      topHop.set(ControlMode.PercentOutput, -.6);
      bottomHop.set(ControlMode.PercentOutput, .2);
     }

     //trigger makes shooter go vroom
    if(stick.getRawButton(1)){

      shooterbottom.set(-0.5); //vroom at fiddy percent
      shootertop.set(-0.5); //vroom fiddy percent

      if(stick.getRawButton(2)){ //if intake button pressed, also move hopper
        
        topHop.set(ControlMode.PercentOutput, -.7);
        bottomHop.set(ControlMode.PercentOutput, .2);

      }

    }

    //climber stuff
    if(stick.getPOV() == 0){ //reverse climber motors
      climber1.set(1);
      climber2.set(1);
    }else if(stick.getPOV() == 180){//forward
      climber1.set(-1);
      climber2.set(-1);
    }

  }






  /**
   * This function is called periodically during test mode.
   */
  @Override
  public void testPeriodic() {
  }
}
