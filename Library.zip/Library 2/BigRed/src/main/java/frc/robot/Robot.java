/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.SpeedControllerGroup;
import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.DoubleSolenoid.Value;
import edu.wpi.first.wpilibj.buttons.Trigger;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.DigitalInput;


/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the TimedRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends TimedRobot {
  
    VictorSP right1 = new VictorSP(2);
    VictorSP right2 = new VictorSP(3);
    VictorSP left1 = new VictorSP(1);
    VictorSP left2 = new VictorSP(0);

    VictorSP shoot1 = new VictorSP(5);
    VictorSP shoot2 = new VictorSP(6);
    VictorSP intake = new VictorSP(8);
    VictorSP hook = new VictorSP(9);
    SpeedControllerGroup left =  new SpeedControllerGroup(right1,right2);
    SpeedControllerGroup right =  new SpeedControllerGroup(left1,left2);


      private final DifferentialDrive m_robotDrive = new DifferentialDrive(right, left);


  private final Joystick m_stick = new Joystick(0);
  private final Joystick m_xBox = new Joystick(1);
  private final Timer m_timer = new Timer();
  DigitalInput limitswitchdown = new DigitalInput(1);
  DigitalInput limitswitchup = new DigitalInput(2);
  

  Compressor compress = new Compressor();
  DoubleSolenoid shootupdown = new DoubleSolenoid(1,6);
  DoubleSolenoid intakeupdown = new DoubleSolenoid(2,5);
  DoubleSolenoid trigger = new DoubleSolenoid(0,7);
  DoubleSolenoid lockPin = new DoubleSolenoid(4,3);


  /**
   * This function is run when the robot is first started up and should be
   * used for any initialization code.
   */
  @Override
  public void robotInit() {
  }

  /**
   * This function is run once each time the robot enters autonomous mode.
   */
  @Override
  public void autonomousInit() {
    m_timer.reset();
    m_timer.start();
  }

  /**
   * This function is called periodically during autonomous.
   */
  @Override
  public void autonomousPeriodic() {
    // Drive for 2 seconds
    if(m_timer.get() < 1.80){
      m_robotDrive.arcadeDrive(0.5 , 0.5); 
    } else {
       m_robotDrive.arcadeDrive(0, 0);
    }
    }
  
  
  
  
  

  /**
   * This function is called once each time the robot enters teleoperated mode.
   */
  @Override
  public void teleopInit() {
  }

  /**
   * This function is called periodically during teleoperated mode.
   */
  @Override
  public void teleopPeriodic() {
    m_robotDrive.arcadeDrive(-m_stick.getY(), m_stick.getZ());
    
  
    if(m_stick.getRawButton(1)){
    trigger.set(Value.kReverse);

  }else{
    trigger.set(Value.kForward);

  }
  
  shoot1.set(0);
  shoot2.set(0);
  intake.set(0);
  
  if(m_stick.getRawButton(2)){
      shoot1.set(1);
      shoot2.set(1);
    } 

  if (m_stick.getRawButton(3)){
    intake.set(1);
    shoot1.set(-1);
    shoot2.set(-1);
  }

  if(m_stick.getRawButtonPressed(4)){
    if(shootupdown.get() == Value.kForward){
    shootupdown.set(Value.kReverse);
  }else{
    shootupdown.set(Value.kForward);

  }}

  if(m_stick.getRawButton(6)){
      intakeupdown.set(Value.kForward);
    } else {
      intakeupdown.set(Value.kReverse);
    }

   if(m_stick.getRawButton(5)){
    if(lockPin.get() == Value.kForward){
    lockPin.set(Value.kReverse);
    } else {
      lockPin.set(Value.kForward);
    }
  
    SmartDashboard.putBoolean("limitSwitchDown", limitswitchdown.get());

   if(!limitswitchdown.get()){
      hook.set(0);
     }

    if(m_xBox.getRawAxis(3) > 0.2){
      hook.set(0.5);
    } else {
      hook.set(0);
    }
    if(m_xBox.getRawAxis(2) > 0.2){
      hook.set(-0.5);
    } else {
      hook.set(0);
    }}
  }
  /**
   * This function is called periodically during test mode.
   */
  @Override
  public void testPeriodic() {
  }
}
