/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/
/*This code is the drive base for a simle robot, and the limelight sensor. */
/*it is used to experiment with the limelight sensor */

package frc.robot;

import java.lang.Math.*;
import edu.wpi.first.wpilibj.Spark;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.DoubleSolenoid.Value;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
//import sun.management.jmxremote.ConnectorBootstrap.DefaultValues;
import edu.wpi.first.cameraserver.CameraServer;
import edu.wpi.first.networktables.NetworkTable;
import edu.wpi.first.networktables.NetworkTableEntry;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.cscore.UsbCamera;
import java.lang.Math;


/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the TimedRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends TimedRobot {
  private final DifferentialDrive m_robotDrive
      = new DifferentialDrive(new Spark(1), new Spark(0));
  private final XboxController Xbox = new XboxController(0);
  private final Timer m_timer = new Timer();
  //Compressor compressor = new Compressor();
  //DoubleSolenoid Solenoid = new DoubleSolenoid(0,7);
  UsbCamera camera2;
  NetworkTableEntry cameraSelection;



  

  /**
   * This function is run when the robot is first started up and should be
   * used for any initialization code.
   */
  @Override
  public void robotInit(){
    camera2 = CameraServer.getInstance().startAutomaticCapture();
    cameraSelection = NetworkTableInstance.getDefault().getTable("").getEntry("CameraSelection");
  }

  /**
   * This function is run once each time the robot enters autonomous mode.
   */
  @Override
  public void autonomousInit() {
    m_timer.reset();
    m_timer.start();
  }

  /**
   * This function is called periodically during autonomous.
   */
  @Override
  public void autonomousPeriodic() {
    // Drive for 2 seconds
   
    
   }
  /**
   * This function is called once each time the robot enters teleoperated mode.
   */
  @Override
  public void teleopInit() {
    
  }

  /**
   * This function is called periodically during teleoperated mode.
   */
  @Override
  public void teleopPeriodic() {
    m_robotDrive.arcadeDrive(-Xbox.getY(), Xbox.getX());
//This tells the limelight to send us its numbers as a network table entry
    final NetworkTable table = NetworkTableInstance.getDefault().getTable("limelight");
    final NetworkTableEntry tx = table.getEntry("tx");
    final NetworkTableEntry ty = table.getEntry("ty");
    final NetworkTableEntry ta = table.getEntry("ta");
    final NetworkTableEntry tv = table.getEntry("tv");

  
    //read values periodically from the network table, turns them into variables
    final double x = tx.getDouble(0.0);
    final double y = ty.getDouble(0.0);
    final double area = ta.getDouble(0.0);
    
    //posts numbers to smart dashboard periodically
    SmartDashboard.putNumber("LimelightX", x);
    SmartDashboard.putNumber("LimelightY", y);
    SmartDashboard.putNumber("LimelightArea", area);


    //this is where all of the variables we used for the targeting get defined
    double min = 0.45;         //the minimum turn speed is 45%
    double max = .9;           //the maximum turn speed is 90%
    double turnSpeed = 0;      //Turnspeed is zero unless otherwise stated.
    double ax = Math.abs(x);   //ax is the absolute vallue of x. this means that ax is just x but not negative.
    double fov = 60;           //the fov of the camera is 60.
    double maxOffset = fov/2;  //the maximum offset, or the maximum vallue of x, is half of the fov, either right or left. the maximum offset is 30.
    double forward = 0;        //forward is the speed of zero unless otherwise defined
    

//This segment is what makes the limelight sensor automatically turn the robot towards its target.
//The limelight doesn't actually control how much the robot turns, it controls the speed of the turn
//when the limelight detects that its cprrect, it sets the turn speed to zero.
    if(x < 0){
      turnSpeed = ax/maxOffset;  //if limelight x is less than 0, turnspeed becomes the absolue vallue of the offset, divided by the max offset which is 30
    }else{
      turnSpeed = x/maxOffset;   //if limelight x is greater than 0, turnspeed becomes x divided by 30.
    }                            //these numbers are expressed as decimals, which become the turnspeed for the arcade drive.

    if(x > 1){

      SmartDashboard.putString("LimelightTolerance","too big");

    if(turnSpeed < min){ //if the turnspeed is less than the minimum, which is 45, it becomes 45
      turnSpeed = min;
    }else if (turnSpeed > max){ //if the turnspeed is greater than the max, which is 90, it becomes 90.
      turnSpeed = max;
    }else{
      
    }

  }else if(x < -1){

    SmartDashboard.putString("LimelightTolerance","too small");

    //TODO below logic isn't working correctly

    if(turnSpeed < min){  //if turnspeed is greater than -.45, turnspeed = -.45
      turnSpeed = -min;
    }else if (turnSpeed > max){   //if turnspeed is less than -.9, turnspeed = -.9
      turnSpeed = -max;
    }else{
       turnSpeed = -turnSpeed;    //if X is less than -1, turn speed equals -turnspeed. if x is less than -1, robot turns left.
    }
        // turnSpeed = -0.5;

  }else{

    SmartDashboard.putString("LimelightTolerance","just right");

    turnSpeed = 0;

  } 

  SmartDashboard.putNumber("Turn Speed", x);  //when button four is pressed the robot turns with a speed that is defined by the limelight
  if(Xbox.getRawButton(4)){
    m_robotDrive.arcadeDrive( 0, turnSpeed);
  }


//this was an experiment that I didn't delete because it's somewhat useful.
//It makes the robot go forward when area, one of the limelight variables, is less than 9
//It goes backwards if its less than 10.
  if (area < 9){
    forward = 0.5;   
  }else if (area > 9){
    forward = -0;
  }
  if(Xbox.getRawButton(3)){
    m_robotDrive.arcadeDrive( forward,0 );
  }
}






  
  /**
   * This function is called periodically during test mode.
   */
  @Override
  public void testPeriodic() {

    final NetworkTable table = NetworkTableInstance.getDefault().getTable("limelight");
    final NetworkTableEntry tx = table.getEntry("tx");
    final NetworkTableEntry ty = table.getEntry("ty");
    final NetworkTableEntry ta = table.getEntry("ta");
    
    //read values periodically
    final double x = tx.getDouble(0.0);
    final double y = ty.getDouble(0.0);
    final double area = ta.getDouble(0.0);
    
    //post to smart dashboard periodically
    SmartDashboard.putNumber("LimelightX", x);
    SmartDashboard.putNumber("LimelightY", y);
    SmartDashboard.putNumber("LimelightArea", area);

  }
}
